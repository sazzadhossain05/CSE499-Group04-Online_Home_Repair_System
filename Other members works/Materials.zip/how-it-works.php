

                
				<br/><br/><br/><br/>
				 <section class="about-meal">
                    <div class="container">
                        <h1 class="section-heading">How It Works</h1>
                        <div class="about-meal-wrap flex">
                             
                            <div class="flex-1">
                                  
                                
							    <h1>Tell Us What To Do</h1><br/>
                                <p>
                                Order any service of Handy Fix is a quick and easy task with few clicks. Select a service category, select sub services, 
								select service quantity, select date & time then confirm the order by providing contact number and address.

                                <br/>If you want to do it more quicker, just call to 09610-222-111 and tell how can we help.
                                 
								</p>
								 <h1>Confirm & Agree</h1><br/>
                                <p>
                                Once you are done with order a service, our customer manager instantly calls you 
								and asks a few questions to collect more details about the service. Upon the consent, 
								customer manager confirms and schedules the service accordingly.
                                 
								</p>
								 <h1>Relax</h1><br/>
                                <p>
                                 What next? Nothing! Now, relax and enjoy Handy Fix Services.
                                 
								</p>
								
                            </div>
							
                        </div>
                    </div>
                </section>
			